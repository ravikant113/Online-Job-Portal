<?php

$c=mysqli_connect("localhost","root","","job_protol");
if(!$c){
    die(mysqli_connect_error($c));

}



?>